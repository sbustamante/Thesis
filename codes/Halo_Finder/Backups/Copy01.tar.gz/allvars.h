/**************************************************************************************************
			      MACROS
**************************************************************************************************/
//Macros generales
#define MAXHALOS	500000
#define MAXPAIRS	10000
#define MAXIPAIR	10000

#define NMAX1		1000
#define NMAX2		10

//Macros of Parameters
#define NOCT		0
#define LBOX		1
#define MMIN		2
#define MMAX		3
#define RREL		4

//Other parameters
#define X		0
#define Y		1
#define Z		2

/**************************************************************************************************
			      ESTRUCTURAS
**************************************************************************************************/
struct halo{
    //Positions
    float r[3];
    //Velocities
    float v[3];
    //Mass
    float Mass;
    //Id
    int id;
    //Region (sub-octant)
    int oct;
    };
    
struct pair{
    //Mass of halo 1
    float M1;
    //id of halo 1
    float id1;
    //Region of halo 1 (sub-octant)
    int oct1;
    
    //Mass of halo 2
    float M2;
    //id of halo 2
    float id2;
    //Region of halo 2 (sub-octant)
    int oct2;
    
    //Relative distances
    float Rdis;
    //Radial relative velocities
    float Vrad;
    //Pair id
    int id_pair;
    };
    
struct region{
    //lower right corner position(xy)
    float Rcor[3];
    //Neighbors
    int neigh[26];
    //number Neighbors
    int Nneigh;
    //Number of pairs in region
    int Npair;
    //ide of region
    int id;
    };
    
/**************************************************************************************************
			      HEADERS
**************************************************************************************************/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#include <proto.h>
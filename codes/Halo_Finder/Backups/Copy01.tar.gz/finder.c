#include <allvars.h>

/**************************************************************************************************
 NAME:	     make_regions
 FUNCTION:   Construct octant regions of box
 INPUTS:     Matrix of region struct, number of octants, length of box
 RETURN:     0
**************************************************************************************************/

int make_regions( struct region regions[NMAX2][NMAX2][NMAX2], int Noct, float Lbox, int index[NMAX1][3] )
{
    int i,j,k;
    int l, m;
    int ic, jc, kc;
    int Nreg = (int)pow(2,3*Noct);
    
    l=0;
    for( i=0; i<pow(2,Noct); i++ )
    for( j=0; j<pow(2,Noct); j++ )
    for( k=0; k<pow(2,Noct); k++ )      
    {
	regions[i][j][k].Rcor[X] = i*Lbox/pow(2,Noct);
	regions[i][j][k].Rcor[X] = j*Lbox/pow(2,Noct);
	regions[i][j][k].Rcor[Z] = k*Lbox/pow(2,Noct);
	regions[i][j][k].id = l;
	l += 1;
	//Index regions construction
	index[l][0] = i; index[l][1] = j; index[l][2] = k;
	regions[i][j][k].Nneigh = 0;
    }
    
    //Setting the Neighborhood
    for( i=0; i<pow(2,Noct); i++ )
    for( j=0; j<pow(2,Noct); j++ )
    for( k=0; k<pow(2,Noct); k++ )      
    {
	l = regions[i][j][k].id;
	
	for( ic=-1; ic<=1; ic++ )
	for( jc=-1; jc<=1; jc++ )
	for( kc=-1; kc<=1; kc++ ){
	    if( i+ic>=0 && i+ic<pow(2,Noct) )
	    if( j+jc>=0 && j+jc<pow(2,Noct) )
	    if( k+kc>=0 && k+kc<pow(2,Noct) )
 	    if( ic!=0 || jc!=0 || kc!=0 ){
		m = regions[i+ic][j+jc][k+kc].Nneigh;
		//Id of neighbors
		regions[i+ic][j+jc][k+kc].neigh[m] = l;
		//Augment number of neighbors
		regions[i+ic][j+jc][k+kc].Nneigh += 1;
	    }}
    }
    
    /*//Setting the Neighborhood
    for( i=0; i<pow(2,Noct); i++ )
    for( j=0; j<pow(2,Noct); j++ )
    for( k=0; k<pow(2,Noct); k++ )      
    {
	printf( "id:%d\ti:%d\tj:%d\tk:%d\t\tNb:%d\n", regions[i][j][k].id, i, j, k, regions[i][j][k].Nneigh  );
	for( l=0; l<=regions[i][j][k].Nneigh; l++ )
  	  printf( "Neib %d: %d\n", l, regions[i][j][k].neigh[l] );
  	printf("\n");
    }*/
    
    return 0;
}
// Data Module
int conf2dump( char * );
int in2dump( char * );
int read_parameters( double *, char * );
int data_in( struct halo *, char *, int );
// int data_out( struct pair *, char * );

//Finder Module
int make_regions( struct region regions[NMAX2][NMAX2][NMAX2], int Noct, float Lbox, int index[NMAX1][3] );
#include <allvars.h>

int main( int argc, char *argv[] )
{   
	//Individual halos
	struct halo *halos;
	halos = (struct halo *)calloc( MAXHALOS, sizeof( struct halo ) );
	//Halo pairs
	struct pair *pairs;
	pairs = (struct pair *)calloc( MAXPAIRS, sizeof( struct pair ) );
	//Isolated halo pairs
	struct pair *isopair;
	isopair = (struct pair *)calloc( MAXIPAIR, sizeof( struct pair ) );
	
	int i,j;
	
	char filename[NMAX1];
	char filenameP[NMAX1];
	char cmd[NMAX1];
	float p[NMAX1];
	
	struct region regions[NMAX2][NMAX2][NMAX2];
	int index[NMAX1][3];
	
	FILE *script;
	
	

	printf( "\n\n************************ HALO PAIR FINDER ***********************\n" );
	//Load Configuration-----------------------------------------------------------------------
	read_parameters( p, "parameters.conf" );
	//Construction of octant regions (PYHTON CODE CALL) [Processed input data file] P<filename>
	  //Input Filename
	sprintf( filename, "%s", "halos.dat" );
  	sprintf( cmd, "python octant.py %d %s", (int)p[NOCT], filename );
     	system( cmd );
	printf( "  * Datafile of halos has been sorted in octant regions!\n" );
	
	//Load Processed input datafile------------------------------------------------------------
 	sprintf( filenameP, "P%s", filename );
	p[NDAT] = data_in( halos, filenameP, p[NOCT] );
	
	//Neighborhood Construction----------------------------------------------------------------
 	make_regions( regions, p[NOCT], p[LBOX], index );
	printf( "  * Neighborhood construction done!\n" );

	//Halo Pair construction-------------------------------------------------------------------
	pair_finder( halos, pairs, isopair, regions, index, p );
	printf( "  * Halo pairs have been found!\n" );
	printf( "  * %d Halos in Mass Range Found!\n", (int)p[HRMAS] );
	
	//Saving Halo Pairs General Sample --------------------------------------------------------
	data_pair_out( pairs, "Pairs.dat", p[PAIR] );
	printf( "  * %d General Pair Halos Found!\n", (int)p[PAIR] );
	
	//Saving Halo Pairs Isolated Sample --------------------------------------------------------
	data_pair_out( isopair, "IsoPairs.dat", p[ISOPAIR] );
	printf( "  * %d Isolated Pair Halos Found!\n", (int)p[ISOPAIR] );
	
    return 0;
}